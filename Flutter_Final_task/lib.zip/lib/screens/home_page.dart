import 'package:flutter/material.dart';
import 'package:fluttersecondapp/screens/home_screen.dart';
import 'package:fluttersecondapp/screens/sports_screen.dart';
import 'package:fluttersecondapp/screens/technology_screen.dart';
import 'package:fluttersecondapp/screens/entertainment_screen.dart';
import 'package:fluttersecondapp/screens/finance_screen.dart';
import 'package:fluttersecondapp/screens/feedback_screen.dart'; // Import Feedback Screen

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Home")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: GridView.count(
          crossAxisCount: 2, // 2 columns
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
          children: [
            _buildCategoryCard(context, "News", Icons.article, const HomeScreen()),
            _buildCategoryCard(context, "Sports", Icons.sports_soccer, const SportsScreen()),
            _buildCategoryCard(context, "Technology", Icons.computer, const TechnologyScreen()),
            _buildCategoryCard(context, "Entertainment", Icons.movie, const EntertainmentScreen()),
            _buildCategoryCard(context, "Finance", Icons.attach_money, const FinanceScreen()),
            _buildCategoryCard(context, "Feedback", Icons.feedback, const FeedbackScreen()), // New Feedback Page
          ],
        ),
      ),
    );
  }

  Widget _buildCategoryCard(BuildContext context, String title, IconData icon, Widget screen) {
    return GestureDetector(
      onTap: () {
        Navigator.push(context, MaterialPageRoute(builder: (context) => screen));
      },
      child: Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        elevation: 4,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 50, color: Colors.blue),
            const SizedBox(height: 10),
            Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}
