import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class SportsScreen extends StatefulWidget {
  const SportsScreen({super.key});

  @override
  _SportsScreenState createState() => _SportsScreenState();
}

class _SportsScreenState extends State<SportsScreen> {
  final String apiKey = "09cf0ac1c6364aa28e2dd19420434c31"; // Replace with your NewsAPI key
  final String category = "sports";
  List articles = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchSportsNews();
  }

  Future<void> fetchSportsNews() async {
    final url = Uri.parse(
        'https://newsapi.org/v2/top-headlines?country=us&category=$category&apiKey=$apiKey');
    final response = await http.get(url);

    if (response.statusCode == 200) {
      setState(() {
        articles = json.decode(response.body)['articles'];
        isLoading = false;
      });
    } else {
      throw Exception('Failed to load news');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Sports News')),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: articles.length,
              itemBuilder: (context, index) {
                return ListTile(
                  leading: articles[index]['urlToImage'] != null
                      ? Image.network(articles[index]['urlToImage'], width: 80, fit: BoxFit.cover)
                      : const Icon(Icons.sports),
                  title: Text(articles[index]['title']),
                  subtitle: Text(articles[index]['source']['name']),
                );
              },
            ),
    );
  }
}
