import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class TechnologyScreen extends StatefulWidget {
  const TechnologyScreen({super.key});

  @override
  _TechnologyScreenState createState() => _TechnologyScreenState();
}

class _TechnologyScreenState extends State<TechnologyScreen> {
  final String apiKey = "09cf0ac1c6364aa28e2dd19420434c31";
  final String category = "technology";
  List articles = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchTechnologyNews();
  }

  Future<void> fetchTechnologyNews() async {
    final url = Uri.parse(
        'https://newsapi.org/v2/top-headlines?country=us&category=$category&apiKey=$apiKey');
    final response = await http.get(url);

    if (response.statusCode == 200) {
      setState(() {
        articles = json.decode(response.body)['articles'];
        isLoading = false;
      });
    } else {
      throw Exception('Failed to load news');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Technology News')),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: articles.length,
              itemBuilder: (context, index) {
                return ListTile(
                  leading: articles[index]['urlToImage'] != null
                      ? Image.network(articles[index]['urlToImage'], width: 80, fit: BoxFit.cover)
                      : const Icon(Icons.computer),
                  title: Text(articles[index]['title']),
                  subtitle: Text(articles[index]['source']['name']),
                );
              },
            ),
    );
  }
}
