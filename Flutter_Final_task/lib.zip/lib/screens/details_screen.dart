import 'package:flutter/material.dart';

class DetailsScreen extends StatelessWidget {
  final Map newsItem;
  const DetailsScreen(this.newsItem, {super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(newsItem['title'])),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            newsItem['urlToImage'] != null
                ? Image.network(newsItem['urlToImage'])
                : Container(height: 200, color: Colors.grey),
            const SizedBox(height: 10),
            Text(
              newsItem['title'],
              style: Theme.of(context).textTheme.bodyLarge,
            ),
            const SizedBox(height: 10),
            Text(
              newsItem['content'] ?? 'No content available',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ],
        ),
      ),
    );
  }
}
